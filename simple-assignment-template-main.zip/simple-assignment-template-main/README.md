This is a nice little template for notebook-based assignments.

- `setup.sh` sets up a virtual environment and installs the requirements
- `build.sh` makes a pdf and a zip of the notebook and puts them both in the out directory